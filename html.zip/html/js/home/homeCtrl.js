define(function (require, exports, module) {
	var app = require('../ng-element')
		,head = require('../common/header')
	head.init({
		app : app
	});
	app.directive('contentRouter',function(){
		return {
	    	restrict : 'E',
	    	replace : true,
	    	transclude : true,
	        templateUrl : '../template/home/index.html',
	        controller : function(){

	        }
	    };
	});
    app.controller('homeCtrl', ['$scope', function($scope) {}]);
});
